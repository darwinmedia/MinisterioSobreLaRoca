// JavaScript Document
jQuery(document).ready(function() {

	jQuery('.animar').addClass("oculto").viewportChecker({

	    classToAdd: 'visible animated flip', // Clases que se agregan cuando el elemento es visible

	    offset: 100    

	   });   

});   

jQuery(document).ready(function() {

	jQuery('.animar1').addClass("oculto").viewportChecker({

	    classToAdd: 'visible animated pulse', // Clases que se agregan cuando el elemento es visible

	    offset: 100    

	   });   

}); 

jQuery(document).ready(function() {

	jQuery('.animar2').addClass("oculto").viewportChecker({

	    classToAdd: 'visible animated fadeIn', // Clases que se agregan cuando el elemento es visible

	    offset: 100    

	   });   

}); 